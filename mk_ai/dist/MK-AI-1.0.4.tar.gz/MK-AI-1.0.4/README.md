# MK-AI

MK-AI is a Python package that allows you to classify stars using the MK system and machine learning.

Documentation at https://starclassification.pages.dev/docs